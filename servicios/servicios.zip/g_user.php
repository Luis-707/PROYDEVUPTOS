<?php
error_reporting(E_ALL);
ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
//  */
 include_once "../clases/Usuario.php";

  //$dataCliente['_post']['login'] = $dataCliente['_post']['otros_datos'];
  // $dataCliente['_post'];

  $usuario = new Usuario2( $dataCliente['_post']);
  $sql = $usuario->sql_buscar_usuario();
  $respuesta = $this->ejecutarConsultaBdds($sql);
/*  echo "---".count($respuesta)."---";
  die(print_r($respuesta));
*/
  if (count($respuesta) == 0) {     
    $sql = $usuario->sql_guardar_usuario();

    $respuesta = $this->ejecutarConsultaBdds($sql);
  }else{
    $respuesta = $dataCliente['_post']['login'].' Ya Existe';
  }
  
  //die(print_r($respuesta[0]));
//die(print_r($data));

 //die($sql);                    
  

  return $respuesta;