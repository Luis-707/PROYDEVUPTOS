<?php
include_once "../clases/Usuario2.php";

$dataCliente['_post']['login'] = $dataCliente['_post']['otros_datos'];


$usuario = new Usuario2($dataCliente['_post']['login'] );

  $sql=$usuario->sql_buscar_usuario();

$respuesta = $this->ejecutarConsultaBdds($sql);
if(empty($respuesta))
return 0;
else
 return 1;