<?php
include_once "../clases/Usuario2.php";

  $dataCliente['_post']['login'] = $dataCliente['_post']['otros_datos'];
  
//print_r($dataCliente['_post']);

  $usuario = new Usuario2($dataCliente['_post']);

  $sql = $usuario->sql_buscar_usuario();
  $respuesta = $this->ejecutarConsultaBdds($sql);

  if (count($respuesta) == 0) {     
    $respuesta = $dataCliente['_post']['login'].' No Existe';
  }else{
    $sql = $usuario->sql_Eliminar_usuario();
    $respuesta = $this->ejecutarConsultaBdds($sql);
  }
  
  return $respuesta;